README — qn_exponents_rep_k12_filled.npz

Purpose
-------
This file encodes a compressed dataset of Collatz–q(n) prime exponents.
It contains one representative for each odd residue class modulo 2^12 (i.e. all odd n < 2^11=2048).

Construction
------------
- Definition:
  The parity code P(n) is the 2-adic integer recording even/odd steps of the Collatz map T.
  The relation is P(n) = -q(n)/3.

- Rows (representatives):
  Each row corresponds to an odd n < 2048. These serve as representatives of the odd residue classes modulo 2^12.
  Array: `row_ids` contains the exact n values.

- Columns (prime exponents):
  Columns correspond to the odd primes appearing in your original dataset (prime 2 was removed, since its valuation is redundant: ν2(q(n))=ν2(n)).
  Array: `col_primes` lists the primes in order.

- Matrix (sparse CSR):
  The matrix entry at [row, col] gives the exponent e such that
      p^e || q(n),   p = col_primes[col].
  Stored in standard SciPy CSR form: data, indices, indptr, shape.

Contents
--------
- data, indices, indptr, shape: CSR sparse matrix arrays.
- col_primes: list of odd primes used as columns.
- row_ids: list of odd n < 2048 serving as representatives.
- k: the compression depth (here 12).

Interpretation
--------------
- There are 1024 rows (all odd residues mod 2^12).
- Each row represents a complete congruence class mod 2^12. Larger n values that are congruent to this representative modulo 2^12 will share the same first 12 Collatz parity steps.
- By increasing k, one could approximate the odd-prime spectrum to higher fidelity, at the cost of more rows.

Usage
-----
Example in Python:

    import numpy as np, scipy.sparse as sp

    npz = np.load("qn_exponents_rep_k12_filled.npz", allow_pickle=True)
    M = sp.csr_matrix((npz["data"], npz["indices"], npz["indptr"]), shape=tuple(npz["shape"]))
    col_primes = npz["col_primes"]
    row_ids = npz["row_ids"]

    # Example: factorization of q(row_ids[0]) across these primes
    row0 = M.getrow(0).toarray()[0]

Limitations
-----------
- Only odd primes are included.
- Compression depth fixed at k=12.
- For higher k you would need to recompute rows up to 2^(k-1).
