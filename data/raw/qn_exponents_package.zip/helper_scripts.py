# Helper scripts for using qn_exponents_rep_k12_filled.npz

import numpy as np
import scipy.sparse as sp

def load_dataset(path="qn_exponents_rep_k12_filled.npz"):
    npz = np.load(path, allow_pickle=True)
    M = sp.csr_matrix((npz["data"], npz["indices"], npz["indptr"]), shape=tuple(npz["shape"]))
    col_primes = npz["col_primes"]
    row_ids = npz["row_ids"]
    return M, col_primes, row_ids

def factorization_row(M, col_primes, row_ids, i):
    """Return dictionary prime->exponent for row i."""
    row = M.getrow(i).toarray()[0]
    return {int(col_primes[j]): int(e) for j, e in enumerate(row) if e > 0}

def collatz_T(n):
    return n//2 if n%2==0 else (3*n+1)//2

def collatz_parity_code_and_q(n, step_cap=100000):
    P = 0
    shift = 0
    x = n
    for _ in range(step_cap):
        bit = x & 1
        if bit:
            P |= (1 << shift)
        if x == 1:
            break
        x = collatz_T(x)
        shift += 1
    else:
        raise RuntimeError(f"Exceeded step cap for n={n}")
    q = -3 * P
    return P, q

def v_p_of_q(q, p):
    q = abs(q)
    e = 0
    while q % p == 0 and q > 0:
        q //= p
        e += 1
    return e
