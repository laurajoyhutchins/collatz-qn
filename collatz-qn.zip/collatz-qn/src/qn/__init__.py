# qn: Collatz q(n) analysis utilities
