Summary of Findings on Prime Factor Frequencies in q(n)

- Data basis: 1024 residue classes at K=11; total incidences 1342 across 148 primes; 2 and 3 excluded.
- Pure 1/p: C≈1044, R^2≈0.51, RMSE≈0.87.
- Relaxed Zipf: best p0≈0, slope≈−0.66 (delta≈−0.34), C_eff≈179, C_mass≈286; R^2≈0.75, RMSE≈0.61.
- Interpretation: finite-K truncation and structural congruences flatten the exponent; expect steepening toward −1 as K grows.
